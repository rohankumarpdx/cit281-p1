/*
    CIT 281 Project 1
    Name: Rohan Kumar
*/
let day = new Date();
let assign = day.getDay();
let weekArray = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
console.log(weekArray[assign]);