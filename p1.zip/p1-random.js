/*
    CIT 281 Project 1
    Name: Rohan Kumar
*/
//Declare all characters allowed in the string:
const availableChars = 'qwertyuiopasdfghjklzxcvbnm';

//Generate string function that takes a specified length
function generateString(stringLength)
{
    //Initialize empty base string
    let base = "";
    const charactersLength = availableChars.length;
    //Loop through string and add a random letter until specified random length has been reached
    for (let i = 0; i < stringLength; i++)
    {
        base += availableChars.charAt(Math.floor(Math.random() * charactersLength));
    }
    return base;
}

// Returns a random number between min (inclusive) and max (exclusive) - AKA length of any given string (copied from project instructions)
function getRandomInteger(min, max) {
    return Math.floor(Math.random() * (max - min) + min);
}

//Print finished random string between 5 and 25 characters
console.log(generateString(getRandomInteger(5, 25)));